package com.payment.service;

import java.util.List;

import com.payment.model.Payment;

public interface PaymentService {

	
	public List<Payment> getPayment();

    public Payment getPaymentById(int paymentId);

   
    public Payment updatePayment(Payment payment);

    public Payment addPayment(Payment payment);
    
}
