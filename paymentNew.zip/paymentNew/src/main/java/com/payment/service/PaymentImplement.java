package com.payment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.model.Payment;
import com.payment.repos.PayRepos;

@Service
public class PaymentImplement implements PaymentService {

	@Autowired
	private PayRepos repo ;
	@Override
	public List<Payment> getPayment() {
		// TODO Auto-generated method stub
		return  repo.findAll();
	}

	@Override
	public Payment getPaymentById(int paymentId) {
		// TODO Auto-generated method stub
		
		return repo.findById(paymentId).orElse(null);
		
	}

	@Override
	public Payment updatePayment(Payment payment) {
		// TODO Auto-generated method stub
		Payment pay = repo.findById(payment.getPaymentId()).orElse(null);
		pay.setAmountPaid(payment.getAmountPaid());
		pay.setDueAmount(payment.getDueAmount());
		pay.setGuestId(payment.getGuestId());
		//pay.setPaymentId(payment.getPaymentId());
		pay.setPaymentMethod(payment.getPaymentMethod());
		pay.setPaymentPurpose(payment.getPaymentPurpose());
		pay.setRoomRent(payment.getRoomRent());
		pay.setTransactionDate(payment.getTransactionDate());
		pay.setTransactionId(payment.getTransactionId());
		
		return repo.save(pay);
	}

	@Override
	public Payment addPayment(Payment payment) {
		// TODO Auto-generated method stub
		 repo.save(payment);
		 return payment ;
	}

}
