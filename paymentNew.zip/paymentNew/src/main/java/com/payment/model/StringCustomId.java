package com.payment.model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class StringCustomId  implements IdentifierGenerator {
	
	
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		// TODO Auto-generated method stub
		String prefix = "SLH_";
		Connection connection = session.connection();

		try {
			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery("select count(guestId) as Id  from Payment ");

			if (rs.next()) {
				int id = rs.getInt(1) + 10000;
				// int id = rs.getInt(1) + 10000 ;-->out - SLH10001 ;
				// int id = rs.getInt(1)+ 00001; --> output - SLH1 ;
				String generatedId = prefix + new Integer(id).toString();
				return generatedId;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return null;
	}

}
