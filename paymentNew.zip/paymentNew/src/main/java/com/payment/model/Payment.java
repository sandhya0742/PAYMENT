package com.payment.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name= "jhon")
public class Payment {

	@Id
	//@GeneratedValue(generator ="guestId")
	//@GenericGenerator(name="guestId" , strategy = "com.custompayment.model.StringCustomId" ) 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "paymentId")
	private int paymentId;
	private String paymentPurpose;
	private String paymentMethod;
	private int dueAmount;
	private int amountPaid;
	private int transactionId;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private java.util.Date transactionDate = new java.util.Date(System.currentTimeMillis());
	@GeneratedValue(generator ="guestId")
	@GenericGenerator(name="guestId" , strategy = "com.custompayment.model.StringCustomId" ) 
	private String guestId;
	private int roomRent;
	
	
	public Payment(int paymentId, String paymentPurpose, String paymentMethod, int dueAmount, int amountPaid,
			int transactionId, Date transactionDate, String guestId, int roomRent) {
		super();
		this.paymentId = paymentId;
		this.paymentPurpose = paymentPurpose;
		this.paymentMethod = paymentMethod;
		this.dueAmount = dueAmount;
		this.amountPaid = amountPaid;
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.guestId = guestId;
		this.roomRent = roomRent;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getPaymentPurpose() {
		return paymentPurpose;
	}
	public void setPaymentPurpose(String paymentPurpose) {
		this.paymentPurpose = paymentPurpose;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public int getDueAmount() {
		return dueAmount;
	}
	public void setDueAmount(int dueAmount) {
		this.dueAmount = dueAmount;
	}
	public int getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(int amountPaid) {
		this.amountPaid = amountPaid;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public java.util.Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(java.util.Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getGuestId() {
		return guestId;
	}
	public void setGuestId(String guestId) {
		this.guestId = guestId;
	}
	public int getRoomRent() {
		return roomRent;
	}
	public void setRoomRent(int roomRent) {
		this.roomRent = roomRent;
	}
	
	public Payment() {
		super();
	}
	
	
	
}
