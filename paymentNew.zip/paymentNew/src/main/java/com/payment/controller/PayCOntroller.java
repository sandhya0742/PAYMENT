package com.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.model.Payment;
import com.payment.service.PaymentService;

@RestController
@RequestMapping("/api")
public class PayCOntroller {
	
	
	@Autowired  
	private  PaymentService serve ;
	
	
	@PostMapping("/addPayment")
	public Payment addPayment(@RequestBody Payment payment ) {
		return this.serve.addPayment(payment);
	}
	
	@PutMapping("/updatePayment")
	public Payment updatePayment(@RequestBody Payment payment) {
		return this.serve.updatePayment(payment);
	}
	
	@GetMapping("/getPaymentDetail/{paymentId}")
	public  Payment getPaymentById(@PathVariable int  paymentId) {
		return this.serve.getPaymentById(paymentId);
	}
	
}
