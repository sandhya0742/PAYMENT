package com.payment.model;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name= "payment")
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "paymentId")
	private int paymentId;
	private String paymentMethod;
	 private double dueAmount;
	 private double amountPaid;
	private String transactionId;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private java.util.Date transactionDate = new java.util.Date(System.currentTimeMillis());
	 @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "guestId")
	    @GenericGenerator(name = "guestId", strategy = "com.payment.model.StringCustomId",
	           parameters = {@Parameter(name = StringCustomId.INCREMENT_PARAM, value = "1"),
 @Parameter(name = StringCustomId.VALUE_PREFIX_PARAMETER, value = "SLH"),
   @Parameter(name = StringCustomId.NUMBER_FORMAT_PARAMETER, value = "%06d")})
	private String guestId;
	 double defaultRent  ;
	 LocalDate checkInDate ;
	private LocalDate checkOutDate ;
	private int remainder ;
	private  double  newDuesAmount ;
	  private boolean onBoard ;
	private  double securityDeposit ;
	// private double  dueDuringOnBoard   ;
	//private String occupancyType[] = { "Daily" , "Monthly" , "Regular" };
       private String occupancyType ;
       private double currentRent ;
	/* 
	 {
        "paymentMethod": "upi",
        "dueAmount": " " ,
        "amountPaid": 3000.0 ,
        "transactionId": 934,
        "transactionDate": "1222-09-05",
        "guestId": "SLH_0002",
        "defaultRent": 6000.0,
        "checkInDate": "1999-09-08",
        "checkOutDate": "1998-07-04T00:00:00.000+00:00",
        "remainder": " " ,
        securityDeposit": 3000.0 ,
        "occupancyType": "Daily",
        "onBoard": "true" ,
        newDuesAmount" : " " 
        }
	*/

	public int getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}


	public String getPaymentMethod() {
		return paymentMethod;
	}


	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}


	public double getDueAmount() {
		return dueAmount;
	}


	public void setDueAmount(double dueAmount) {
		this.dueAmount = dueAmount;
	}


	public double getAmountPaid() {
		return amountPaid;
	}


	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public java.util.Date getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(java.util.Date transactionDate) {
		this.transactionDate = transactionDate;
	}


	public String getGuestId() {
		return guestId;
	}


	public void setGuestId(String guestId) {
		this.guestId = guestId;
	}


	public double getDefaultRent() {
		return defaultRent;
	}


	public void setDefaultRent(double defaultRent) {
		this.defaultRent = defaultRent;
	}


	public LocalDate getCheckInDate() {
		return checkInDate;
	}


	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}


	public LocalDate getCheckOutDate() {
		return checkOutDate;
	}


	public void setCheckOutDate(LocalDate checkOutDate) {
		this.checkOutDate = checkOutDate;
	}


	public int getRemainder() {
		return remainder;
	}


	public void setRemainder(int remainder) {
		this.remainder = remainder;
	}


	public double getNewDuesAmount() {
		return newDuesAmount;
	}


	public void setNewDuesAmount(double newDuesAmount) {
		this.newDuesAmount = newDuesAmount;
	}


	public boolean isOnBoard() {
		return onBoard;
	}


	public void setOnBoard(boolean onBoard) {
		this.onBoard = onBoard;
	}


	public double getSecurityDeposit() {
		return securityDeposit;
	}


	public void setSecurityDeposit(double securityDeposit) {
		this.securityDeposit = securityDeposit;
	}


	public String getOccupancyType() {
		return occupancyType;
	}


	public void setOccupancyType(String occupancyType) {
		this.occupancyType = occupancyType;
	}
	
	public double getCurrentRent() {
		return currentRent;
	}


	public void setCurrentRent(double currentRent) {
		this.currentRent = currentRent;
	}
	


	public Payment() {
		super();
	}
	

	public Payment(int paymentId, String paymentMethod, double dueAmount, double amountPaid, String transactionId,
			Date transactionDate, String guestId, double defaultRent, LocalDate checkInDate, LocalDate checkOutDate,
	  String occupancyType ,int remainder ,double newDuesAmount , boolean onBoard, double securityDeposit ,
	double  dueDuringOnBOard , double currentRent  ) {
		super();
		this.paymentId = paymentId;
		this.paymentMethod = paymentMethod;
		this.dueAmount = dueAmount;
		this.amountPaid = amountPaid;
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.guestId = guestId;
		this.defaultRent = defaultRent;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.occupancyType  = occupancyType ;
		this.remainder = remainder ;
		this.newDuesAmount = newDuesAmount ;
		this.onBoard = onBoard ;
		this.currentRent = currentRent ;
		this.securityDeposit = securityDeposit ;
	}


	

	
	/*
	public double getDueAmount() {
		LocalDate checkInDate = LocalDate.now() ;
		int remainder = checkInDate.getDayOfMonth();

	double count=securityDeposit+defaultRent;
		dueAmount =   count;
	
	
	if(remainder <30 && remainder  > 1) {
		
		 dueAmount =  (defaultRent/30)*remainder ;
	}
	 if (onBoard == true ) {
		
		newDuesAmount  = dueAmount - amountPaid ;
	}
	 
	 */
		
	/*
	public double getAmountPaid() {
		if(occupancyType.toString().equals("Daily")) {
			
		amountPaid = (defaultRent/30)* remainder ;
			
			
		}else if (occupancyType.toString().equals("Monthly")) {
			
			 amountPaid  = defaultRent ;
			
		}else if (occupancyType.toString().equals("Regular")){
			
			amountPaid = defaultRent ;
			System.out.println("Exception");
		}
		return amountPaid;
	}
	*/
	
	/*
	public double getDefaultRent() {
		if(occupancyType.toString().equals("Daily")) {
			defaultRent = defaultRent/30;
		
			
		}else if (occupancyType.toString().equals("Monthly")) {
			defaultRent = amountPaid;
			
		}else if (occupancyType.toString().equals("Regular")){
			defaultRent = amountPaid;		
		}	
		return defaultRent ;		
	}
	*/
}




